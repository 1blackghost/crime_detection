import pandas as pd
import numpy as np
import pickle


# Load the trained model
with open("safety_model.pkl", "rb") as f:
    model, state_mapping, district_mapping, scaler = pickle.load(f)

# Function to predict crime score
def predict_crime_score(state, district):
    if state not in state_mapping or district not in district_mapping:
        return None  # Invalid input
    
    state_encoded = state_mapping[state]
    district_encoded = district_mapping[district]
    
    crime_score = model.predict(np.array([[state_encoded, district_encoded]]))[0]
    return round(crime_score, 2)


state_name = "KERALA"
district_name ="KANNUR"
    
crime_score = predict_crime_score(state_name, district_name)
print(crime_score)