import torch
import cv2
import numpy as np
from ultralytics import YOLO

model = YOLO("best.pt")

class_names = ['Knife_Weapon', 'Person', 'mask']

def detect_objects(image_path):
    image = cv2.imread(image_path)
    if image is None:
        print("Error: Could not load image.")
        return
    
    results = model(image)

    person_detected = False
    knife_detected = False
    mask_detected = False

    for result in results:
        for box in result.boxes:
            class_id = int(box.cls[0])  
            conf = float(box.conf[0])  
            x1, y1, x2, y2 = map(int, box.xyxy[0])  
            
            if conf >= 0.6:
                if class_id == class_names.index('Person'):
                    person_detected = True
                elif class_id == class_names.index('Knife_Weapon'):
                    knife_detected = True
                elif class_id == class_names.index('mask'):
                    mask_detected = True


    if (knife_detected or mask_detected):
        return True

