import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, MinMaxScaler
from sklearn.ensemble import RandomForestRegressor
import pickle


data = pd.read_csv("1.csv")

data.columns = data.columns.str.strip()

features = ["STATE/UT", "DISTRICT"]
target = ["Rape", "Kidnapping and Abduction", "Dowry Deaths", 
          "Assault on women with intent to outrage her modesty", "Insult to modesty of Women", 
          "Cruelty by Husband or his Relatives", "Importation of Girls"]

le_state = LabelEncoder()
le_district = LabelEncoder()

data["STATE/UT"] = le_state.fit_transform(data["STATE/UT"])
data["DISTRICT"] = le_district.fit_transform(data["DISTRICT"])

state_mapping = dict(zip(le_state.classes_, le_state.transform(le_state.classes_)))
district_mapping = dict(zip(le_district.classes_, le_district.transform(le_district.classes_)))

data["Crime Score"] = data[target].sum(axis=1)

scaler = MinMaxScaler(feature_range=(1, 10))
data["Safety Score"] = 10 - scaler.fit_transform(data[["Crime Score"]])

X = data[features]
y = data["Safety Score"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

with open("safety_model.pkl", "wb") as f:
    pickle.dump((model, state_mapping, district_mapping, scaler), f)

def predict_safety(state, district):
    with open("safety_model.pkl", "rb") as f:
        model, state_mapping, district_mapping, scaler = pickle.load(f)
    
    if state not in state_mapping or district not in district_mapping:
        return "Error: Invalid State or District name. Make sure it's spelled correctly."
    
    state_encoded = state_mapping[state]
    district_encoded = district_mapping[district]
    
    safety_score = model.predict(np.array([[state_encoded, district_encoded]]))[0]
    return round(safety_score, 2)

if __name__ == "__main__":
    state_input = input("Enter State/UT: ").strip().upper()
    district_input = input("Enter District: ").strip().upper()
    
    score = predict_safety(state_input, district_input)
    print(f"Predicted Safety Score (1-10): {score}")
