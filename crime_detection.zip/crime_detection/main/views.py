from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.http import JsonResponse
from django.db import IntegrityError
from .models import User  
from django.views.decorators.csrf import csrf_exempt
from loadModel import predict_crime_score
import os
import pickle
import numpy as np
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from django.conf import settings
import torch
import cv2
import numpy as np
from ultralytics import YOLO


def detect_objects(image_path):
        
    model = YOLO("best.pt")

    class_names = ['Knife_Weapon', 'Person', 'mask']
    image = cv2.imread(image_path)
    if image is None:
        print("Error: Could not load image.")
        return
    
    results = model(image)

    person_detected = False
    knife_detected = False
    mask_detected = False

    for result in results:
        for box in result.boxes:
            class_id = int(box.cls[0])  
            conf = float(box.conf[0])  
            x1, y1, x2, y2 = map(int, box.xyxy[0])  
            
            if conf >= 0.6:
                if class_id == class_names.index('Person'):
                    person_detected = True
                elif class_id == class_names.index('Knife_Weapon'):
                    knife_detected = True
                elif class_id == class_names.index('mask'):
                    mask_detected = True


    if (knife_detected or mask_detected):
        return True
    else:
        return False


MODEL_PATH = "safety_model.pkl"

with open(MODEL_PATH, "rb") as f:
    model, state_mapping, district_mapping, scaler = pickle.load(f)

def predict_crime_score(state, district):
    state = state.upper()
    district = district.upper()

    if state not in state_mapping or district not in district_mapping:
        return None  
    state_encoded = state_mapping[state]
    district_encoded = district_mapping[district]

    crime_score = model.predict(np.array([[state_encoded, district_encoded]]))[0]
    return round(crime_score, 2)

@csrf_exempt
def prediction(request):
    if request.method == "POST":
        state = request.POST.get("state", "").strip().upper()
        district = request.POST.get("district", "").strip().upper()

        print(f"Received: State={state}, District={district}") 

        if not state or not district:
            return JsonResponse({"error": "State and district are required"}, status=400)

        crime_score = predict_crime_score(state, district)
        if crime_score is None:
            return JsonResponse({"error": "Invalid state or district"}, status=400)

        print(f"Predicted Crime Score: {crime_score}")
        return JsonResponse({"crime_score": crime_score})

    return JsonResponse({"error": "Invalid request method"}, status=400)

def home(request):
    return render(request, "index.html")  

def login(request):
    return render(request, "login.html")  

def signup(request):
    return render(request, "signup.html") 
def dash(request):
    return render(request, "dash.html") 

@csrf_exempt
def signup_view(request):
    if request.method == "POST":
        name = request.POST.get("username")
        email = request.POST.get("email")
        password = request.POST.get("password")
        confirm_password = request.POST.get("confpassw")

        print(f"Received signup data: Username={name}, Email={email}, Password={password}, Confirm Password={confirm_password}")

        if password != confirm_password:
            return JsonResponse({"error": "Passwords do not match"}, status=400)

        if User.objects.filter(email=email).exists():
            return JsonResponse({"error": "Email already registered"}, status=400)

        try:
            user = User(name=name, email=email, password=password) 
            user.save()


            return JsonResponse({"success": "User registered successfully"})
        except IntegrityError:
            return JsonResponse({"error": "User already exists"}, status=400)

    return JsonResponse({"error": "Invalid request method"}, status=400)


@csrf_exempt
def login_view(request):
    if request.method == "POST":
        email = request.POST.get("email")
        password = request.POST.get("password")

        print(f"Received login data: Email={email}, Password={password}")

        try:
            user = User.objects.get(email=email, password=password)  
        except User.DoesNotExist:
            return JsonResponse({"error": "Invalid email or password"}, status=400)

        request.session['user_id'] = user.id
        request.session['user_email'] = user.email

        return JsonResponse({"success": "Login successful"})

    return JsonResponse({"error": "Invalid request method"}, status=400)


@csrf_exempt
def logout(request):
    request.session.flush()  
    return redirect('/login')  

@csrf_exempt
def upload_image(request):
    if request.method == "POST" and request.FILES.get("image"):
        image = request.FILES["image"]

        static_dir = settings.STATICFILES_DIRS[0] if settings.STATICFILES_DIRS else os.path.join(settings.BASE_DIR, "static")

        upload_dir = os.path.join(static_dir, "uploads")
        os.makedirs(upload_dir, exist_ok=True)

        file_path = os.path.join(upload_dir, image.name)
        with open(file_path, "wb") as f:
            for chunk in image.chunks():
                f.write(chunk)
        x=detect_objects(image_path=upload_dir+"\\"+image.name)

        return JsonResponse({"success": True, "file_path": f"/static/uploads/{image.name}","result":x})

    return JsonResponse({"success": False, "error": "No image uploaded."})