import pandas as pd
import numpy as np
import pickle

data = pd.read_csv("1.csv")
data.columns = data.columns.str.strip()

with open("safety_model.pkl", "rb") as f:
    model, state_mapping, district_mapping, scaler = pickle.load(f)

def predict_crime_score(state, district):
    if state not in state_mapping or district not in district_mapping:
        return None  
    
    state_encoded = state_mapping[state]
    district_encoded = district_mapping[district]
    
    crime_score = model.predict(np.array([[state_encoded, district_encoded]]))[0]
    return round(crime_score, 2)

moderate_risk_places = []

for _, row in data.iterrows():
    state_name = row["STATE/UT"]
    district_name = row["DISTRICT"]
    
    crime_score = predict_crime_score(state_name, district_name)
    
    if crime_score is not None and 5 <= crime_score <= 8:
        moderate_risk_places.append((state_name, district_name, crime_score))

moderate_risk_places.sort(key=lambda x: x[2])

if moderate_risk_places:
    print("\nPlaces with Crime Scores Between 5 and 8:")
    for state, district, score in moderate_risk_places:
        print(f"{district}, {state} - Score: {score}")
else:
    print("No places found with crime scores between 5 and 8.")
